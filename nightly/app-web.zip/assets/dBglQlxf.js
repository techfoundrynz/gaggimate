const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/B4dXJlNC.js","assets/Ctd_jhc1.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./e8wCKb8j.js";import{registerPlugin as o}from"./Ctd_jhc1.js";const i=o("Preferences",{web:()=>r(()=>import("./B4dXJlNC.js"),__vite__mapDeps([0,1])).then(e=>new e.PreferencesWeb)});export{i as Preferences};
